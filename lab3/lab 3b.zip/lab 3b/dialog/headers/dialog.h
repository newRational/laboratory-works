#ifndef TASK_DIALOG_H
#define TASK_DIALOG_H

#include "Diagram.h"

void dialog(Diagram &d);
Diagram create();

#endif
