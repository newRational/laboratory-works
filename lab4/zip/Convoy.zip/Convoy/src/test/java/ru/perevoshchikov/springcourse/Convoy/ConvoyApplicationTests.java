package ru.perevoshchikov.springcourse.Convoy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConvoyApplicationTests {

	@Test
	void contextLoads() {
	}

}
