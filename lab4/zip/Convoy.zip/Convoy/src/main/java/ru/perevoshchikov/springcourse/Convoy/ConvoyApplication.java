package ru.perevoshchikov.springcourse.Convoy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConvoyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConvoyApplication.class, args);
	}

}
